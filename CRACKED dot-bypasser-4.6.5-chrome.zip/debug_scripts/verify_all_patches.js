// verify_all_patches.js — kiểm tra toàn bộ patch.
//  background.js: new Function(content) không throw; đếm debugger; giảm đúng 3; Patch3/4 hiện diện.
//  chunks/main-CCifN7s3.js: copy .mjs tạm rồi `node --check`; Patch6/6b old KHÔNG còn, new CÓ.
const fs = require('fs');
const cp = require('child_process');
const os = require('os');
const path = require('path');
const BG = 'C:\\Users\\Administrator\\Desktop\\CODE\\dot-bypasser-4.6.5-chrome\\background.js';
const MAIN = 'C:\\Users\\Administrator\\Desktop\\CODE\\dot-bypasser-4.6.5-chrome\\chunks\\main-CCifN7s3.js';
let ok = true;
const chk = (cond, msg) => { console.log((cond ? '  [PASS] ' : '  [FAIL] ') + msg); if (!cond) ok = false; };

// ---------- background.js ----------
console.log('=== background.js ===');
let bg = fs.readFileSync(BG, 'utf8'); if (bg.charCodeAt(0) === 0xFEFF) bg = bg.slice(1);
const dbg = (bg.match(/debugger;/g) || []).length;
chk(dbg === 19, 'debugger; count = 19 (was 22, -3)  [actual ' + dbg + ']');
chk(bg.startsWith('chrome.storage.local.set({"enabled":true,"hasAgreedDisclaimer":true});'), 'Patch 4: storage seed ở đầu file');
chk(!bg.includes('ewKjUor(){"use strict";debugger;'), 'Patch 1: ewKjUor debugger đã bỏ');
chk(!bg.includes('jEwONM(){"use strict";debugger;'), 'Patch 1: jEwONM debugger đã bỏ');
chk(!bg.includes('aRYOk3Y(){"use strict";debugger;'), 'Patch 1: aRYOk3Y debugger đã bỏ');
chk(bg.includes('hOeeoIS(yNQeVM[0x306])+yNQeVM[0x132]]:!0})'), 'Patch 3: isPremium return -> premium:!0');
chk(!bg.includes('hOeeoIS(yNQeVM[0x306])+yNQeVM[0x132]]:PrHJBY})'), 'Patch 3: old return đã thay');
try { new Function(bg); chk(true, 'new Function(background.js) không throw'); }
catch (e) { chk(false, 'new Function throw: ' + e.message); }

// ---------- main-CCifN7s3.js ----------
console.log('\n=== chunks/main-CCifN7s3.js ===');
let mn = fs.readFileSync(MAIN, 'utf8'); if (mn.charCodeAt(0) === 0xFEFF) mn = mn.slice(1);
chk(!mn.includes('oc()||!(await Od())'), 'Patch 6: COND cũ đã biến mất');
chk(mn.includes('(false)&&('), 'Patch 6: `(false)&&(` xuất hiện (short-circuit)');
chk(!mn.includes('(async()=>{var HeIw8Sv,zZafXeW;zZafXeW=void 0x0;const VBMSz1=await Fe('), 'Patch 6b: IIFE update-check cũ đã biến mất');
chk((mn.match(/\(async\(\)=>\{\}\)\(\)/g) || []).length >= 1, 'Patch 6b: stub `(async()=>{})()` xuất hiện');
const tmp = path.join(os.tmpdir(), 'main_check_' + Date.now() + '.mjs');
fs.writeFileSync(tmp, mn, 'utf8');
try { cp.execSync('node --check "' + tmp + '"', { stdio: 'pipe' }); chk(true, 'node --check (ES module) OK'); }
catch (e) { chk(false, 'node --check FAIL: ' + (e.stderr ? e.stderr.toString().split('\n')[0] : e.message)); }
finally { try { fs.unlinkSync(tmp); } catch (e) {} }

console.log('\n==== ' + (ok ? 'TẤT CẢ PASS' : 'CÓ FAIL — xem trên') + ' ====');
process.exit(ok ? 0 : 1);
