// patch_4_storage.js — Patch 4: seed storage để bypass gate lúc khởi động.
// Chèn vào ĐẦU background.js (sau BOM nếu có):
//   chrome.storage.local.set({"enabled":true,"hasAgreedDisclaimer":true});
// Key lấy từ Patch 5 (decode_storage_keys.js): "enabled" (default true), "hasAgreedDisclaimer" (default false).
const fs = require('fs');
const P = 'C:\\Users\\Administrator\\Desktop\\CODE\\dot-bypasser-4.6.5-chrome\\background.js';
const INJECT = 'chrome.storage.local.set({"enabled":true,"hasAgreedDisclaimer":true});';

function run() {
  let c = fs.readFileSync(P, 'utf8');
  const bom = c.charCodeAt(0) === 0xFEFF; if (bom) c = c.slice(1);
  if (c.startsWith(INJECT)) { console.log('Patch 4 đã có sẵn, bỏ qua.'); return; }
  c = INJECT + c;
  fs.writeFileSync(P, (bom ? '\uFEFF' : '') + c, 'utf8');
  console.log('Patch 4 injected: ' + INJECT);
}
run();
