// find_debugger.js — Patch 1 locator
// Tìm mọi `debugger;` trong background.js, xác định cái nằm ngay đầu async message-dispatcher function.
const fs = require('fs');
const path = 'C:\\Users\\Administrator\\Desktop\\CODE\\dot-bypasser-4.6.5-chrome\\background.js';
let c = fs.readFileSync(path, 'utf8');
if (c.charCodeAt(0) === 0xFEFF) c = c.slice(1);

// đếm tất cả debugger;
let idxs = [];
let i = -1;
while ((i = c.indexOf('debugger;', i + 1)) !== -1) idxs.push(i);
console.log('Total `debugger;` occurrences:', idxs.length);

// Tìm pattern: destructure rỗng var[[],X]=arguments; NGAY SAU debugger;
const reArgs = /debugger;var\[\[\],([A-Za-z0-9_$]+)\]=arguments;/g;
let m, hits = [];
while ((m = reArgs.exec(c)) !== null) {
  // tên function: lùi lại tìm "async function NAME()"
  const before = c.slice(Math.max(0, m.index - 80), m.index);
  const fm = before.match(/async function ([A-Za-z0-9_$]+)\(\)\{"use strict";$/);
  hits.push({ index: m.index, varName: m[1], match: m[0], fnName: fm ? fm[1] : null });
}
console.log('\n`debugger;var[[],X]=arguments;` matches:', hits.length);
for (const h of hits) {
  console.log('  idx=' + h.index, 'fn=' + h.fnName, 'var=' + h.varName);
}

// Cross-verify: cái nào được gọi qua `case COND:return NAME(this,`
console.log('\n--- switch dispatcher call-site check: `return FN(this,` ---');
for (const h of hits) {
  if (!h.fnName) continue;
  const reCall = new RegExp('case [^:]{1,40}:return ' + h.fnName + '\\(this,', 'g');
  const found = [...c.matchAll(reCall)];
  const anyReturnThis = [...c.matchAll(new RegExp('return ' + h.fnName + '\\(this,', 'g'))];
  console.log('  fn=' + h.fnName, '| `case ...:return FN(this,` =', found.length, '| any `return FN(this,` =', anyReturnThis.length);
  if (anyReturnThis.length) {
    const ci = anyReturnThis[0].index;
    console.log('    ctx:', JSON.stringify(c.slice(Math.max(0, ci - 50), ci + 30)));
  }
}
module.exports = { hits };
