// patch_5_unofficial.js — Patch 6 (fingerprint gate "Unofficial Source") trong chunks/main-CCifN7s3.js
// Site duy nhất `||!(await `:  Pi(async()=>{...nJgStg(zZafXeW=void 0,(oc()||!(await Od()))&&(
//     OjeIeD["value"]&&(OjeIeD["value"]=false),  // disable "enabled"
//     ...unofficialModal.open()... , me(OjeIeD, cb=>{...}))) })
//   OjeIeD = ref useStorage("enabled") (đã verify ở Patch 5). COND set enabled=false + mở modal Unofficial.
// PATCH: thay COND `oc()||!(await Od())` -> `false` => short-circuit && , né mọi side-effect.
const fs = require('fs');
const P = 'C:\\Users\\Administrator\\Desktop\\CODE\\dot-bypasser-4.6.5-chrome\\chunks\\main-CCifN7s3.js';
const OLD = 'oc()||!(await Od())';
const NEW = 'false';

function run() {
  let c = fs.readFileSync(P, 'utf8');
  const bom = c.charCodeAt(0) === 0xFEFF; if (bom) c = c.slice(1);
  const n = c.split(OLD).length - 1;
  if (n !== 1) throw new Error('[P6] COND occurrence != 1 (=' + n + ') -> KHÔNG patch');
  c = c.replace(OLD, NEW);
  fs.writeFileSync(P, (bom ? '\uFEFF' : '') + c, 'utf8');
  console.log('Patch 6 applied: `' + OLD + '` -> `' + NEW + '`');
}
run();
