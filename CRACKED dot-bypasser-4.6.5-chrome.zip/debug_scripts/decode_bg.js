// decode_bg.js — dựng lại decoder chuỗi của background.js (top-level hOeeoIS + mảng yNQeVM) trong vm sandbox.
// background.js là VM-obfuscated (generator state-machine). Ta chèn capture SỚM (ngay sau yNQeVM]) để lấy
// tham chiếu hOeeoIS (hoisted) + yNQeVM (đã xoay in-place sau khi phần đồng bộ chạy tới top-level await đầu tiên).
// LƯU Ý: chỉ dùng cho call-site DÙNG top-level hOeeoIS (tail wrappers, cexLG_...). Trong các hàm có hOeeoIS
// shadow riêng, kết quả sẽ SAI — không dùng cho vùng đó.
const fs = require('fs'), vm = require('vm');
const P = 'C:\\Users\\Administrator\\Desktop\\CODE\\dot-bypasser-4.6.5-chrome\\background.js';

function buildBgDecoder() {
  let c = fs.readFileSync(P, 'utf8'); if (c.charCodeAt(0) === 0xFEFF) c = c.slice(1);
  const capture = ';try{globalThis.__H=typeof hOeeoIS==="function"?hOeeoIS:null;globalThis.__Y=typeof yNQeVM!=="undefined"?yNQeVM:null;}catch(e){globalThis.__E=String(e);}';
  const yEnd = c.indexOf('];', c.indexOf('const yNQeVM=[')) + 2;
  const src = c.slice(0, yEnd) + capture + c.slice(yEnd);
  const wrapped = '(async()=>{' + src + '\n})().catch(()=>{});';
  const universal = new Proxy(function () {}, {
    get: (t, k) => typeof k === 'symbol' ? undefined : universal,
    apply: () => universal, construct: () => universal, has: () => true, set: () => true,
  });
  const base = {
    console, Math, Object, Array, String, Number, Boolean, JSON, Symbol, Date, RegExp, Error, TypeError,
    RangeError, isNaN, parseInt, parseFloat, encodeURIComponent, decodeURIComponent, Uint8Array, Uint16Array,
    Int32Array, Float64Array, ArrayBuffer, DataView, Map, Set, WeakMap, WeakSet, Promise, Function, Buffer,
    Proxy, Reflect, globalThis: null,
    TextDecoder: (typeof TextDecoder !== 'undefined' ? TextDecoder : undefined),
    TextEncoder: (typeof TextEncoder !== 'undefined' ? TextEncoder : undefined),
    setTimeout: () => 0, clearTimeout: () => {}, setInterval: () => 0, clearInterval: () => {},
  };
  const handler = { has: () => true, get: (t, k) => { if (k in t) return t[k]; if (typeof k === 'symbol') return undefined; return universal; }, set: (t, k, v) => { t[k] = v; return true; } };
  const sandbox = new Proxy(base, handler); base.globalThis = sandbox;
  const ctx = vm.createContext(sandbox);
  try { vm.runInContext(wrapped, ctx, { filename: 'bg.js', timeout: 30000 }); } catch (e) {}
  const H = base.__H, Y = base.__Y;
  if (typeof H !== 'function' || !Array.isArray(Y)) throw new Error('bg decoder init fail');

  // decSnippet: thay hOeeoIS(yNQeVM[0xNN]) và hOeeoIS(0xNN) bằng «fragment», gộp +.
  const clean = s => String(s).replace(/[\u00ab\u00bb]/g, '');
  function decSnippet(s) {
    let t = s.replace(/hOeeoIS\(yNQeVM\[(0x[0-9a-f]+)\]\)/g, (m, h) => { let v; try { v = H(Y[parseInt(h)]); } catch (e) { v = null; } return v == null ? m : '\u00ab' + clean(v) + '\u00bb'; });
    t = t.replace(/hOeeoIS\((0x[0-9a-f]+)\)/g, (m, h) => { let v; try { v = H(parseInt(h)); } catch (e) { v = null; } return v == null ? m : '\u00ab' + clean(v) + '\u00bb'; });
    // yNQeVM[0xNN] bare khi là string
    t = t.replace(/yNQeVM\[(0x[0-9a-f]+)\]/g, (m, h) => { const v = Y[parseInt(h)]; return typeof v === 'string' ? '\u00ab' + clean(v) + '\u00bb' : m; });
    let p; do { p = t; t = t.replace(/\u00bb\+\u00ab/g, ''); } while (t !== p);
    return t;
  }
  return { H, Y, decSnippet };
}
module.exports = { buildBgDecoder };

if (require.main === module) {
  const fs2 = require('fs');
  let c = fs2.readFileSync(P, 'utf8'); if (c.charCodeAt(0) === 0xFEFF) c = c.slice(1);
  const { decSnippet } = buildBgDecoder();
  const names = process.argv.slice(2);
  function extractFn(name) {
    const re = new RegExp('async function ' + name + '\\([^)]*\\)\\{|function ' + name + '\\([^)]*\\)\\{');
    const mm = re.exec(c); if (!mm) return null;
    let bi = mm.index + mm[0].length - 1, depth = 0, inStr = null, esc = false;
    for (let i = bi; i < c.length; i++) { const ch = c[i]; if (esc) { esc = false; continue; } if (inStr) { if (ch === '\\') esc = true; else if (ch === inStr) inStr = null; continue; } if (ch === '"' || ch === "'" || ch === '`') { inStr = ch; continue; } if (ch === '{') depth++; else if (ch === '}') { depth--; if (depth === 0) return c.slice(mm.index, i + 1); } }
    return null;
  }
  for (const n of names) {
    const b = extractFn(n);
    console.log('\n######## ' + n + ' ########');
    if (!b) { console.log('NOT FOUND'); continue; }
    console.log(decSnippet(b.length > 1400 ? b.slice(0, 1400) + '...[+' + (b.length - 1400) + ']' : b));
  }
}
