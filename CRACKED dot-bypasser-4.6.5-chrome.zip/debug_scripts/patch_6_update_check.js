// patch_6_update_check.js — Patch 6b: stub IIFE remote update-check trong chunks/main-CCifN7s3.js.
// IIFE gọi RPC Fe("getLatestVersion") -> background fetch remote; fail-closed mở modal
// updateCheckFailedModal / updateModal / disabledModal. Stub -> `(async()=>{})()` : không network,
// state modal giữ falsy nên không modal nào .open(). Vars trong IIFE local; side-effect (mở modal,
// set state failed) chỉ thuộc feature update-check nên bỏ an toàn.
const fs = require('fs');
const { locateUpdateIife } = require('./decode_update_strings.js');
const P = 'C:\\Users\\Administrator\\Desktop\\CODE\\dot-bypasser-4.6.5-chrome\\chunks\\main-CCifN7s3.js';
const STUB = '(async()=>{})()';

function run() {
  const { start, end } = locateUpdateIife();
  let c = fs.readFileSync(P, 'utf8');
  const bom = c.charCodeAt(0) === 0xFEFF; if (bom) c = c.slice(1);
  const iife = c.slice(start, end);
  if (!iife.startsWith('(async()=>{var ') || !iife.endsWith(')()')) throw new Error('IIFE bounds sai');
  const occ = c.split(iife).length - 1;
  if (occ !== 1) throw new Error('IIFE occurrence != 1 (=' + occ + ')');
  c = c.slice(0, start) + STUB + c.slice(end);
  fs.writeFileSync(P, (bom ? '\uFEFF' : '') + c, 'utf8');
  console.log('Patch 6b applied: stubbed update-check IIFE (' + iife.length + ' chars) -> ' + STUB);
  console.log('char after stub:', JSON.stringify(c.slice(start + STUB.length, start + STUB.length + 3)));
}
run();
