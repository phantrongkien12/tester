// patch_1_2_3.js — Patch cho background.js
//   Patch 1: xoá anti-debug `debugger;` ở đầu 3 message-handler (ewKjUor/jEwONM/aRYOk3Y).
//            (Runbook baseline 1 statement; build 4.6.5 có 3 handler-entry cùng shape
//             `debugger;var[[],X]=arguments;` được dispatch qua `case ...:return FN(this,` -> xoá cả 3.)
//   Patch 3: override license/premium — cexLG_ đăng ký RPC "isPremium" trả {premium:PrHJBY};
//            đổi giá trị trả về của nhánh mặc định thành true (key "premium").
//   Patch 2: KHÔNG áp (xem CLAUDE.md) — không tồn tại "integrity-check trigger" tách biệt ở bản này;
//            anti-tamper là inline `while(1){}` kích bằng newline-detection, edit minified không thêm
//            newline nên không kích hoạt.
const fs = require('fs');
const P = 'C:\\Users\\Administrator\\Desktop\\CODE\\dot-bypasser-4.6.5-chrome\\background.js';

function replaceOnce(c, oldStr, newStr, label) {
  const n = c.split(oldStr).length - 1;
  if (n !== 1) throw new Error('[' + label + '] occurrence != 1 (=' + n + ') -> KHÔNG patch');
  return c.replace(oldStr, newStr);
}

function run() {
  let c = fs.readFileSync(P, 'utf8');
  const bom = c.charCodeAt(0) === 0xFEFF; if (bom) c = c.slice(1);
  const before = (c.match(/debugger;/g) || []).length;

  // Patch 1 (x3): bỏ `debugger;`
  c = replaceOnce(c,
    'ewKjUor(){"use strict";debugger;var[[],nUoRG1c]=arguments;',
    'ewKjUor(){"use strict";var[[],nUoRG1c]=arguments;', 'P1-ewKjUor');
  c = replaceOnce(c,
    'jEwONM(){"use strict";debugger;var[[],Zqkk9RK]=arguments;',
    'jEwONM(){"use strict";var[[],Zqkk9RK]=arguments;', 'P1-jEwONM');
  c = replaceOnce(c,
    'aRYOk3Y(){"use strict";debugger;var[[],nUoRG1c]=arguments;',
    'aRYOk3Y(){"use strict";var[[],nUoRG1c]=arguments;', 'P1-aRYOk3Y');

  // Patch 3: cexLG_ isPremium default return -> premium:true
  //   `[hOeeoIS(yNQeVM[0x306])+yNQeVM[0x132]]:PrHJBY})`  (key = "premium")
  c = replaceOnce(c,
    'hOeeoIS(yNQeVM[0x306])+yNQeVM[0x132]]:PrHJBY})',
    'hOeeoIS(yNQeVM[0x306])+yNQeVM[0x132]]:!0})', 'P3-premium-return');

  const after = (c.match(/debugger;/g) || []).length;
  fs.writeFileSync(P, (bom ? '\uFEFF' : '') + c, 'utf8');
  console.log('debugger; before=' + before + ' after=' + after + ' (removed ' + (before - after) + ')');
  console.log('Patch 1 (x3) + Patch 3 applied. Patch 2 KHÔNG áp (deferred).');
}
run();
