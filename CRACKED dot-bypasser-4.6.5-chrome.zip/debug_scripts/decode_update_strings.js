// decode_update_strings.js — định vị IIFE remote update-check trong chunks/main-CCifN7s3.js bằng CẤU TRÚC.
// IIFE: `(async()=>{var ...;const X=await Fe("getLatestVersion")[...];if(!(X&&X["tag_name"])){...="failed";
//        updateCheckFailedModal.open();return} if(hu(X["tag_name"],ac)){...} ...})()`
// Cách tìm: quét mọi `(async()=>{var ` -> decode 900 ký tự -> giữ cái chứa getLatestVersion/tag_name/failed.
// Trả {start,end} (end = sau `()` gọi IIFE) qua balanced-paren scan. KHÔNG hardcode offset.
const fs = require('fs');
const { buildDecoder } = require('./decode_storage_keys.js');
const P = 'C:\\Users\\Administrator\\Desktop\\CODE\\dot-bypasser-4.6.5-chrome\\chunks\\main-CCifN7s3.js';

function loadSrc() {
  let c = fs.readFileSync(P, 'utf8'); const bom = c.charCodeAt(0) === 0xFEFF; if (bom) c = c.slice(1);
  return { c, bom };
}

function locateUpdateIife() {
  const { c } = loadSrc();
  const { TaKM9wz, t4BcFX } = buildDecoder();
  const clean = s => String(s).replace(/[«»]/g, '');
  const decSnip = (s) => {
    let t = s.replace(/TaKM9wz\(t4BcFX\[(0x[0-9a-f]+)\]\)/g, (m, h) => { let v; try { v = TaKM9wz(t4BcFX[parseInt(h)]); } catch (e) { v = null; } return v == null ? m : '«' + clean(v) + '»'; });
    t = t.replace(/TaKM9wz\((0x[0-9a-f]+)\)/g, (m, h) => { let v; try { v = TaKM9wz(parseInt(h)); } catch (e) { v = null; } return v == null ? m : '«' + clean(v) + '»'; });
    t = t.replace(/t4BcFX\[(0x[0-9a-f]+)\]/g, (m, h) => { const v = t4BcFX[parseInt(h)]; return typeof v === 'string' ? '«' + clean(v) + '»' : m; });
    let p; do { p = t; t = t.replace(/»\+«/g, ''); } while (t !== p);
    return t;
  };
  const re = /\(async\(\)=>\{var /g; let m; const found = [];
  while ((m = re.exec(c)) !== null) {
    const dec = decSnip(c.slice(m.index, m.index + 900));
    if (/getLatestVersion/.test(dec) && /tag_name/.test(dec) && /failed/.test(dec)) {
      found.push({ start: m.index, dec });
    }
  }
  if (found.length !== 1) throw new Error('update-check IIFE tìm được != 1 (=' + found.length + ')');
  const start = found[0].start;
  // balanced paren scan: (async()=>{...})  rồi mong đợi "()"
  let depth = 0, inStr = null, esc = false, wrapClose = -1;
  for (let i = start; i < c.length; i++) {
    const ch = c[i];
    if (esc) { esc = false; continue; }
    if (inStr) { if (ch === '\\') esc = true; else if (ch === inStr) inStr = null; continue; }
    if (ch === '"' || ch === "'" || ch === '`') { inStr = ch; continue; }
    if (ch === '(') depth++;
    else if (ch === ')') { depth--; if (depth === 0) { wrapClose = i; break; } }
  }
  if (wrapClose === -1 || c.slice(wrapClose + 1, wrapClose + 3) !== '()') throw new Error('không scan được bounds IIFE');
  const end = wrapClose + 3;
  return { start, end, dec: found[0].dec };
}

module.exports = { locateUpdateIife, loadSrc };

if (require.main === module) {
  const r = locateUpdateIife();
  console.log('update-check IIFE @raw', r.start, '..', r.end, 'len', r.end - r.start);
  console.log('DEC head:', r.dec.slice(0, 320));
}
