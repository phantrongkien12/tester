// decode_storage_keys.js
// Dựng lại decoder string-table của chunks/main-CCifN7s3.js trong vm sandbox.
// Chunk là ES module có top-level await => wrap toàn bộ trong async IIFE, inject capture point
// ngay sau khi bảng chuỗi (VBMSz1) init xong (chạy đồng bộ trước await đầu tiên), rồi expose:
//   TaKM9wz : public decode fn (index -> plaintext)
//   t4BcFX  : index-literal array
//   dec(hex): = TaKM9wz(t4BcFX[hex])  (giải mã đúng call-site TaKM9wz(t4BcFX[0xNNN]))
const fs = require('fs');
const vm = require('vm');
const P = 'C:\\Users\\Administrator\\Desktop\\CODE\\dot-bypasser-4.6.5-chrome\\chunks\\main-CCifN7s3.js';

function buildDecoder() {
  let c = fs.readFileSync(P, 'utf8');
  if (c.charCodeAt(0) === 0xFEFF) c = c.slice(1);
  // strip ES module import/export (đúng 1 mỗi loại; import nằm giữa file nên không anchor)
  c = c.replace(/import\{[^}]*\}from"[^"]*";?/g, '');
  c = c.replace(/export\{[^}]*\};?/g, '');

  // Tìm điểm inject: sau statement `nJgStg(zZafXeW={},VBMSz1=[...])` đứng ngay sau def TaKM9wz.
  const tkPos = c.indexOf('function TaKM9wz(');
  if (tkPos === -1) throw new Error('không tìm thấy TaKM9wz');
  const initMarker = 'nJgStg(zZafXeW={},VBMSz1=[';
  const initPos = c.indexOf(initMarker, tkPos);
  if (initPos === -1) throw new Error('không tìm thấy VBMSz1 init');
  // balanced paren scan từ '(' sau nJgStg
  let pOpen = initPos + 'nJgStg'.length; // vị trí '('
  let depth = 0, inStr = null, esc = false, injectAt = -1;
  for (let i = pOpen; i < c.length; i++) {
    const ch = c[i];
    if (esc) { esc = false; continue; }
    if (inStr) { if (ch === '\\') esc = true; else if (ch === inStr) inStr = null; continue; }
    if (ch === '"' || ch === "'" || ch === '`') { inStr = ch; continue; }
    if (ch === '(') depth++;
    else if (ch === ')') { depth--; if (depth === 0) { injectAt = i + 1; break; } }
  }
  if (injectAt === -1) throw new Error('không scan được VBMSz1 init end');

  const capture = ';try{globalThis.__CAP={t:TaKM9wz,a:t4BcFX,n:VBMSz1.length};}catch(e){globalThis.__CAPERR=String(e);}';
  const src = c.slice(0, injectAt) + capture + c.slice(injectAt);
  const wrapped = '(async()=>{' + src + '\n})().catch(()=>{});';

  const universal = new Proxy(function () {}, {
    get: (t, k) => (typeof k === 'symbol') ? undefined : universal,
    apply: () => universal, construct: () => universal, has: () => true, set: () => true,
  });
  const base = {
    console, Math, Object, Array, String, Number, Boolean, JSON, Symbol, Date, RegExp,
    Error, TypeError, RangeError, isNaN, parseInt, parseFloat, encodeURIComponent, decodeURIComponent,
    Uint8Array, Uint16Array, Int32Array, Float64Array, ArrayBuffer, Map, Set, WeakMap, WeakSet,
    Promise, Function, Buffer, globalThis: null,
    TextDecoder: (typeof TextDecoder !== 'undefined' ? TextDecoder : undefined),
    TextEncoder: (typeof TextEncoder !== 'undefined' ? TextEncoder : undefined),
    setTimeout: () => 0, clearTimeout: () => {}, setInterval: () => 0, clearInterval: () => {},
  };
  const handler = {
    has: () => true,
    get: (t, k) => { if (k in t) return t[k]; if (typeof k === 'symbol') return undefined; return universal; },
    set: (t, k, v) => { t[k] = v; return true; },
  };
  const sandbox = new Proxy(base, handler);
  base.globalThis = sandbox;
  const ctx = vm.createContext(sandbox);
  try {
    vm.runInContext(wrapped, ctx, { filename: 'main-decoded.js', timeout: 30000 });
  } catch (e) {
    if (process.env.DBG) console.log('[note] threw:', e && e.message);
  }
  const cap = base.__CAP;
  if (process.env.DBG) console.log('[dbg] __CAP set=', !!cap, 'err=', base.__CAPERR);
  if (!cap || typeof cap.t !== 'function' || !Array.isArray(cap.a)) {
    throw new Error('Decoder không init được (CAP=' + (cap ? 'partial' : 'null') + ', err=' + base.__CAPERR + ')');
  }
  const TaKM9wz = cap.t, t4BcFX = cap.a, vlen = cap.n;
  const dec = (hex) => TaKM9wz(t4BcFX[hex]);
  return { TaKM9wz, t4BcFX, dec, vlen };
}

// Trích 2 storage key thật từ 2 call-site useStorage `Ft(<key>,<default>,{writeDefaults,...})`.
// Được xác định bằng VAI TRÒ: key default TRUE = "enabled" (ref dùng ở fingerprint gate),
// key default FALSE = "hasAgreedDisclaimer". (đã verify bằng option object decode ra
// "writeDefaults"/"listenToStorageChanges" = tuỳ chọn @vueuse/core useStorage)
function extractStorageKeys() {
  const fs2 = require('fs');
  let c = fs2.readFileSync(P, 'utf8'); if (c.charCodeAt(0) === 0xFEFF) c = c.slice(1);
  const { TaKM9wz, t4BcFX } = buildDecoder();
  const clean = s => String(s).replace(/[«»]/g, '');
  // decode 1 đoạn ngắn: thay TaKM9wz(t4BcFX[..]) + t4BcFX[..] string literal, gộp +
  const decChunk = (s) => {
    let t = s.replace(/TaKM9wz\(t4BcFX\[(0x[0-9a-f]+)\]\)/g, (m, h) => { let v; try { v = TaKM9wz(t4BcFX[parseInt(h)]); } catch (e) { v = null; } return v == null ? m : '«' + clean(v) + '»'; });
    t = t.replace(/t4BcFX\[(0x[0-9a-f]+)\]/g, (m, h) => { const v = t4BcFX[parseInt(h)]; return typeof v === 'string' ? '«' + clean(v) + '»' : m; });
    let p; do { p = t; t = t.replace(/»\+«/g, ''); } while (t !== p);
    return t;
  };
  // tìm call-site Ft("enabled",...) và Ft("hasAgreedDisclaimer",...)
  const out = {};
  const dfull = decChunk(c);
  const mEnabled = dfull.match(/Ft\(«([^»]*)»,!t4BcFX\[0x0\],\{\[«writeDefaults»\]/);
  const mDisc = dfull.match(/Ft\(«([^»]*)»,!t4BcFX\[0x4\],\{\[«writeDefaults»\]/);
  out.enabledKey = mEnabled ? mEnabled[1] : null;   // default !0 = true
  out.disclaimerKey = mDisc ? mDisc[1] : null;      // default !1 = false
  return out;
}

if (require.main === module) {
  const keys = extractStorageKeys();
  console.log('== Storage keys (cho Patch 4) ==');
  console.log('enabled_key         =', JSON.stringify(keys.enabledKey), '(default true)');
  console.log('hasAgreedDisclaimer =', JSON.stringify(keys.disclaimerKey), '(default false)');
}

module.exports.extractStorageKeys = extractStorageKeys;

module.exports = { buildDecoder };
